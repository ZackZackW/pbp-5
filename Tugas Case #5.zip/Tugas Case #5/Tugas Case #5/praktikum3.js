// Praktikum 3: Operator dan perhitungan luas
const sisi = 5;
const alas = 10;
const tinggi = 6;
const jariJari = 7;

const luasPersegi = sisi * sisi;
const luasSegitiga = 0.5 * alas * tinggi;
const luasLingkaran = Math.PI * jariJari * jariJari;

console.log("=== Menghitung Luas Bangun Datar ===");
console.log(`Luas persegi (sisi ${sisi}): ${luasPersegi}`);
console.log(`Luas segitiga (alas ${alas}, tinggi ${tinggi}): ${luasSegitiga}`);
console.log(`Luas lingkaran (jari-jari ${jariJari}): ${luasLingkaran.toFixed(2)}`);
