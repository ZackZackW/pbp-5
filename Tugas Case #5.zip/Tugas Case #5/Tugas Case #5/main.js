// Berkas utama untuk menjalankan salah satu praktikum.
// Contoh: node main.js 5
const nomor = process.argv[2];

if (!nomor || !["1", "2", "3", "4", "5", "6"].includes(nomor)) {
  console.log("Gunakan: node main.js <nomor praktikum 1-6>");
  process.exit(0);
}

require(`./praktikum${nomor}.js`);
