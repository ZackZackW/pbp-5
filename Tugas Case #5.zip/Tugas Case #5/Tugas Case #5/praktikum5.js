// Praktikum 5: Menentukan bilangan ganjil atau genap
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Masukkan sebuah angka: ", (input) => {
  const angka = parseInt(input, 10);

  if (!Number.isInteger(angka)) {
    console.log("Input harus berupa bilangan bulat.");
  } else if (angka % 2 === 0) {
    console.log(`${angka} adalah bilangan genap.`);
  } else {
    console.log(`${angka} adalah bilangan ganjil.`);
  }

  rl.close();
});
