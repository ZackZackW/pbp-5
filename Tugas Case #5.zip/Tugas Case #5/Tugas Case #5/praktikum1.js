// Praktikum 1: Variabel dan Konstanta
let nama = "Zacky";
let umur = 18;
const kampus = "Universitas Nusa Putra";

console.log("=== Variabel dan Konstanta ===");
console.log("Nama:", nama);
console.log("Umur:", umur);
console.log("Kampus:", kampus);

// Contoh mengubah nilai variabel
nama = "Ibnu Zacky";
umur = 19;
console.log("\nSetelah nilai variabel diubah:");
console.log("Nama:", nama);
console.log("Umur:", umur);
// const tidak dapat diubah setelah dideklarasikan.
