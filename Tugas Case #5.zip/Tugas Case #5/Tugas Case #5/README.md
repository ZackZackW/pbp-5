# Praktikum Dasar-Dasar JavaScript — PBP Sesi 2

**Mata kuliah:** Pemrograman Berbasis Platform  
**Dosen:** Shinta Ayuningtias, S.Kom., M.Kom.  
**Nama:** Muhammad Ibnu Zacky  
**NIM:** 20250040088

## Isi proyek
- `praktikum1.js` — variabel dan konstanta
- `praktikum2.js` — tipe data
- `praktikum3.js` — operator dan luas bangun datar
- `praktikum4.js` — input dan konversi dengan `parseInt()` / `parseFloat()`
- `praktikum5.js` — menentukan ganjil atau genap
- `praktikum6.js` — menghitung nilai akhir mahasiswa
- `main.js` — menjalankan praktikum berdasarkan nomor
- `hasil_program/` — contoh hasil pengujian

## Persyaratan
Pastikan Node.js sudah terpasang. Periksa dengan:
```bash
node --version
```

## Cara menjalankan
Buka terminal di folder ini, lalu jalankan salah satu perintah:
```bash
node praktikum1.js
node praktikum2.js
node praktikum3.js
node praktikum4.js
node praktikum5.js
node praktikum6.js
```

Atau gunakan berkas utama:
```bash
node main.js 1
node main.js 2
# ganti angka 1 dengan nomor praktikum 1 sampai 6
```

Praktikum 4, 5, dan 6 meminta input melalui terminal. Ikuti pertanyaan yang muncul.

## Contoh pengujian
- Praktikum 4: nama `Zacky`, umur `18`, tinggi `170.5`.
- Praktikum 5: masukkan `8` untuk genap, lalu uji lagi dengan `7` untuk ganjil.
- Praktikum 6: nama `Zacky`, tugas `80`, UTS `85`, UAS `90`. Nilai akhir = `85.50`.

## Rumus nilai akhir
Nilai akhir = (Tugas × 30%) + (UTS × 30%) + (UAS × 40%).

## Pertanyaan analisis singkat
1. `let` digunakan untuk variabel yang nilainya dapat diubah, sedangkan `const` digunakan untuk pengikatan yang tidak dapat ditetapkan ulang.
2. `typeof` digunakan untuk memeriksa tipe data suatu nilai.
3. Operator `*` digunakan untuk perkalian dan `%` untuk mendapatkan sisa pembagian.
4. `parseInt()` mengubah input menjadi bilangan bulat dan `parseFloat()` mengubah input menjadi bilangan desimal.
5. Kondisi `angka % 2 === 0` berarti bilangan genap; selain itu bilangan ganjil.
6. Nilai akhir dihitung menggunakan bobot tugas 30%, UTS 30%, dan UAS 40%.

## Catatan
Berkas `hasil_program` berisi contoh output untuk referensi. Jalankan setiap script di komputer sendiri dan ambil screenshot terminal asli sebagai bukti praktikum jika dosen meminta screenshot.
