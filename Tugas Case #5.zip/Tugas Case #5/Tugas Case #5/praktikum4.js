// Praktikum 4: Input dan Konversi Data
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Masukkan nama: ", (nama) => {
  rl.question("Masukkan umur (bilangan bulat): ", (umurInput) => {
    rl.question("Masukkan tinggi badan (cm): ", (tinggiInput) => {
      const umur = parseInt(umurInput, 10);
      const tinggi = parseFloat(tinggiInput);

      if (!Number.isInteger(umur) || Number.isNaN(tinggi)) {
        console.log("Input umur atau tinggi tidak valid.");
      } else {
        console.log("\n=== Data Pengguna ===");
        console.log("Nama:", nama);
        console.log("Umur:", umur, "| tipe:", typeof umur);
        console.log("Tinggi:", tinggi, "cm | tipe:", typeof tinggi);
      }
      rl.close();
    });
  });
});
