// Praktikum 2: Tipe Data
let alamat = "Bandung";
let nilai = 85;
let lulus = true;

console.log("=== Tipe Data ===");
console.log("Alamat:", alamat, "| tipe:", typeof alamat);
console.log("Nilai:", nilai, "| tipe:", typeof nilai);
console.log("Lulus:", lulus, "| tipe:", typeof lulus);
