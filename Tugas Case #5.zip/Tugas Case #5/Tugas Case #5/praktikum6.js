// Praktikum 6: Mini Project Menghitung Nilai Akhir Mahasiswa
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Nama mahasiswa: ", (nama) => {
  rl.question("Nilai tugas (0-100): ", (tugasInput) => {
    rl.question("Nilai UTS (0-100): ", (utsInput) => {
      rl.question("Nilai UAS (0-100): ", (uasInput) => {
        const tugas = parseFloat(tugasInput);
        const uts = parseFloat(utsInput);
        const uas = parseFloat(uasInput);

        const valid = [tugas, uts, uas].every(
          (nilai) => Number.isFinite(nilai) && nilai >= 0 && nilai <= 100
        );

        if (!valid) {
          console.log("Nilai harus berupa angka dari 0 sampai 100.");
        } else {
          const nilaiAkhir = tugas * 0.30 + uts * 0.30 + uas * 0.40;
          console.log("\n=== Hasil Nilai Akhir ===");
          console.log("Nama:", nama);
          console.log("Nilai tugas (30%):", tugas);
          console.log("Nilai UTS (30%):", uts);
          console.log("Nilai UAS (40%):", uas);
          console.log("Nilai akhir:", nilaiAkhir.toFixed(2));
        }
        rl.close();
      });
    });
  });
});
